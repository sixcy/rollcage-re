Rollcage track editor — experimental local game export

1. Keep your original installation and IMG/IDX files unchanged.
2. Make a separate copy of your Rollcage Redux installation.
3. Replace BOTH IDXData/Rollcage.img and IDXData/Rollcage.idx in that copy.
4. Enable weapons/pickups when testing pickup changes. Edits apply to LOW and HIGH.

To continue editing, reopen the same starting archives used for this project and load track-project.json.
Keep those starting files with the project. The IMG/IDX in this ZIP contain the exported edits and form a new starting point.
This export contains pickup and supported plain scenery edits together.
Scenery collision uses preserved native shapes and rebuilt conservative spatial candidate lists.
Scenery exports have parser/browser validation; original-process game compatibility is not yet established.
Special/destructible/animated objects, Blender import and LEV16/17 editing are unsupported.

Edited archive entries: 48, 49, 64, 65, 88, 89, 104, 105