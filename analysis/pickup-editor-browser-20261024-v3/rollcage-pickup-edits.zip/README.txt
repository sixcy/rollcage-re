Rollcage pickup editor — local game export

1. Keep your original installation and original IMG/IDX files unchanged.
2. Make a separate copy of your Rollcage Redux installation.
3. In that copy, replace BOTH IDXData/Rollcage.img and IDXData/Rollcage.idx with the files from this ZIP.
4. Enable weapons/pickups in the game. Edits apply to LOW and HIGH versions of each edited level.

To continue editing: open your ORIGINAL archives in the track viewer, then load pickup-project.json.
This project changes pickup spawn points only. It preserves the original random weapon awards and respawn definitions.
LEV15, LEV16 and LEV17 are excluded. Maximum 16 pickup points per level.
Game compatibility is validated against Rollcage Redux 1.3.8.0.

Edited archive entries: 30, 32, 70, 72